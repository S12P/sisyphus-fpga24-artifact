// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XKERNEL_GEMVER_H
#define XKERNEL_GEMVER_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xkernel_gemver_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XKernel_gemver_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XKernel_gemver;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XKernel_gemver_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XKernel_gemver_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XKernel_gemver_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XKernel_gemver_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XKernel_gemver_Initialize(XKernel_gemver *InstancePtr, UINTPTR BaseAddress);
XKernel_gemver_Config* XKernel_gemver_LookupConfig(UINTPTR BaseAddress);
#else
int XKernel_gemver_Initialize(XKernel_gemver *InstancePtr, u16 DeviceId);
XKernel_gemver_Config* XKernel_gemver_LookupConfig(u16 DeviceId);
#endif
int XKernel_gemver_CfgInitialize(XKernel_gemver *InstancePtr, XKernel_gemver_Config *ConfigPtr);
#else
int XKernel_gemver_Initialize(XKernel_gemver *InstancePtr, const char* InstanceName);
int XKernel_gemver_Release(XKernel_gemver *InstancePtr);
#endif

void XKernel_gemver_Start(XKernel_gemver *InstancePtr);
u32 XKernel_gemver_IsDone(XKernel_gemver *InstancePtr);
u32 XKernel_gemver_IsIdle(XKernel_gemver *InstancePtr);
u32 XKernel_gemver_IsReady(XKernel_gemver *InstancePtr);
void XKernel_gemver_Continue(XKernel_gemver *InstancePtr);
void XKernel_gemver_EnableAutoRestart(XKernel_gemver *InstancePtr);
void XKernel_gemver_DisableAutoRestart(XKernel_gemver *InstancePtr);

void XKernel_gemver_Set_alpha(XKernel_gemver *InstancePtr, u32 Data);
u32 XKernel_gemver_Get_alpha(XKernel_gemver *InstancePtr);
void XKernel_gemver_Set_beta(XKernel_gemver *InstancePtr, u32 Data);
u32 XKernel_gemver_Get_beta(XKernel_gemver *InstancePtr);
void XKernel_gemver_Set_A(XKernel_gemver *InstancePtr, u64 Data);
u64 XKernel_gemver_Get_A(XKernel_gemver *InstancePtr);
void XKernel_gemver_Set_u1(XKernel_gemver *InstancePtr, u64 Data);
u64 XKernel_gemver_Get_u1(XKernel_gemver *InstancePtr);
void XKernel_gemver_Set_v1(XKernel_gemver *InstancePtr, u64 Data);
u64 XKernel_gemver_Get_v1(XKernel_gemver *InstancePtr);
void XKernel_gemver_Set_u2(XKernel_gemver *InstancePtr, u64 Data);
u64 XKernel_gemver_Get_u2(XKernel_gemver *InstancePtr);
void XKernel_gemver_Set_v2(XKernel_gemver *InstancePtr, u64 Data);
u64 XKernel_gemver_Get_v2(XKernel_gemver *InstancePtr);
void XKernel_gemver_Set_w(XKernel_gemver *InstancePtr, u64 Data);
u64 XKernel_gemver_Get_w(XKernel_gemver *InstancePtr);
void XKernel_gemver_Set_x(XKernel_gemver *InstancePtr, u64 Data);
u64 XKernel_gemver_Get_x(XKernel_gemver *InstancePtr);
void XKernel_gemver_Set_y(XKernel_gemver *InstancePtr, u64 Data);
u64 XKernel_gemver_Get_y(XKernel_gemver *InstancePtr);
void XKernel_gemver_Set_z(XKernel_gemver *InstancePtr, u64 Data);
u64 XKernel_gemver_Get_z(XKernel_gemver *InstancePtr);

void XKernel_gemver_InterruptGlobalEnable(XKernel_gemver *InstancePtr);
void XKernel_gemver_InterruptGlobalDisable(XKernel_gemver *InstancePtr);
void XKernel_gemver_InterruptEnable(XKernel_gemver *InstancePtr, u32 Mask);
void XKernel_gemver_InterruptDisable(XKernel_gemver *InstancePtr, u32 Mask);
void XKernel_gemver_InterruptClear(XKernel_gemver *InstancePtr, u32 Mask);
u32 XKernel_gemver_InterruptGetEnabled(XKernel_gemver *InstancePtr);
u32 XKernel_gemver_InterruptGetStatus(XKernel_gemver *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
