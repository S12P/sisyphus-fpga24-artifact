// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xkernel_gemver.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XKernel_gemver_CfgInitialize(XKernel_gemver *InstancePtr, XKernel_gemver_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XKernel_gemver_Start(XKernel_gemver *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_AP_CTRL) & 0x80;
    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XKernel_gemver_IsDone(XKernel_gemver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XKernel_gemver_IsIdle(XKernel_gemver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XKernel_gemver_IsReady(XKernel_gemver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XKernel_gemver_Continue(XKernel_gemver *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_AP_CTRL) & 0x80;
    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_AP_CTRL, Data | 0x10);
}

void XKernel_gemver_EnableAutoRestart(XKernel_gemver *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XKernel_gemver_DisableAutoRestart(XKernel_gemver *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_AP_CTRL, 0);
}

void XKernel_gemver_Set_alpha(XKernel_gemver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_ALPHA_DATA, Data);
}

u32 XKernel_gemver_Get_alpha(XKernel_gemver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_ALPHA_DATA);
    return Data;
}

void XKernel_gemver_Set_beta(XKernel_gemver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_BETA_DATA, Data);
}

u32 XKernel_gemver_Get_beta(XKernel_gemver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_BETA_DATA);
    return Data;
}

void XKernel_gemver_Set_A(XKernel_gemver *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_A_DATA, (u32)(Data));
    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_A_DATA + 4, (u32)(Data >> 32));
}

u64 XKernel_gemver_Get_A(XKernel_gemver *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_A_DATA);
    Data += (u64)XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_A_DATA + 4) << 32;
    return Data;
}

void XKernel_gemver_Set_u1(XKernel_gemver *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_U1_DATA, (u32)(Data));
    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_U1_DATA + 4, (u32)(Data >> 32));
}

u64 XKernel_gemver_Get_u1(XKernel_gemver *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_U1_DATA);
    Data += (u64)XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_U1_DATA + 4) << 32;
    return Data;
}

void XKernel_gemver_Set_v1(XKernel_gemver *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_V1_DATA, (u32)(Data));
    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_V1_DATA + 4, (u32)(Data >> 32));
}

u64 XKernel_gemver_Get_v1(XKernel_gemver *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_V1_DATA);
    Data += (u64)XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_V1_DATA + 4) << 32;
    return Data;
}

void XKernel_gemver_Set_u2(XKernel_gemver *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_U2_DATA, (u32)(Data));
    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_U2_DATA + 4, (u32)(Data >> 32));
}

u64 XKernel_gemver_Get_u2(XKernel_gemver *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_U2_DATA);
    Data += (u64)XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_U2_DATA + 4) << 32;
    return Data;
}

void XKernel_gemver_Set_v2(XKernel_gemver *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_V2_DATA, (u32)(Data));
    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_V2_DATA + 4, (u32)(Data >> 32));
}

u64 XKernel_gemver_Get_v2(XKernel_gemver *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_V2_DATA);
    Data += (u64)XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_V2_DATA + 4) << 32;
    return Data;
}

void XKernel_gemver_Set_w(XKernel_gemver *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_W_DATA, (u32)(Data));
    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_W_DATA + 4, (u32)(Data >> 32));
}

u64 XKernel_gemver_Get_w(XKernel_gemver *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_W_DATA);
    Data += (u64)XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_W_DATA + 4) << 32;
    return Data;
}

void XKernel_gemver_Set_x(XKernel_gemver *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_X_DATA, (u32)(Data));
    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_X_DATA + 4, (u32)(Data >> 32));
}

u64 XKernel_gemver_Get_x(XKernel_gemver *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_X_DATA);
    Data += (u64)XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_X_DATA + 4) << 32;
    return Data;
}

void XKernel_gemver_Set_y(XKernel_gemver *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_Y_DATA, (u32)(Data));
    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_Y_DATA + 4, (u32)(Data >> 32));
}

u64 XKernel_gemver_Get_y(XKernel_gemver *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_Y_DATA);
    Data += (u64)XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_Y_DATA + 4) << 32;
    return Data;
}

void XKernel_gemver_Set_z(XKernel_gemver *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_Z_DATA, (u32)(Data));
    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_Z_DATA + 4, (u32)(Data >> 32));
}

u64 XKernel_gemver_Get_z(XKernel_gemver *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_Z_DATA);
    Data += (u64)XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_Z_DATA + 4) << 32;
    return Data;
}

void XKernel_gemver_InterruptGlobalEnable(XKernel_gemver *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_GIE, 1);
}

void XKernel_gemver_InterruptGlobalDisable(XKernel_gemver *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_GIE, 0);
}

void XKernel_gemver_InterruptEnable(XKernel_gemver *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_IER);
    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_IER, Register | Mask);
}

void XKernel_gemver_InterruptDisable(XKernel_gemver *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_IER);
    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_IER, Register & (~Mask));
}

void XKernel_gemver_InterruptClear(XKernel_gemver *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_gemver_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_ISR, Mask);
}

u32 XKernel_gemver_InterruptGetEnabled(XKernel_gemver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_IER);
}

u32 XKernel_gemver_InterruptGetStatus(XKernel_gemver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XKernel_gemver_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_GEMVER_CONTROL_ADDR_ISR);
}

