// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 4  - ap_continue (Read/Write/SC)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of alpha
//        bit 31~0 - alpha[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of beta
//        bit 31~0 - beta[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of A
//        bit 31~0 - A[31:0] (Read/Write)
// 0x24 : Data signal of A
//        bit 31~0 - A[63:32] (Read/Write)
// 0x28 : reserved
// 0x2c : Data signal of u1
//        bit 31~0 - u1[31:0] (Read/Write)
// 0x30 : Data signal of u1
//        bit 31~0 - u1[63:32] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of v1
//        bit 31~0 - v1[31:0] (Read/Write)
// 0x3c : Data signal of v1
//        bit 31~0 - v1[63:32] (Read/Write)
// 0x40 : reserved
// 0x44 : Data signal of u2
//        bit 31~0 - u2[31:0] (Read/Write)
// 0x48 : Data signal of u2
//        bit 31~0 - u2[63:32] (Read/Write)
// 0x4c : reserved
// 0x50 : Data signal of v2
//        bit 31~0 - v2[31:0] (Read/Write)
// 0x54 : Data signal of v2
//        bit 31~0 - v2[63:32] (Read/Write)
// 0x58 : reserved
// 0x5c : Data signal of w
//        bit 31~0 - w[31:0] (Read/Write)
// 0x60 : Data signal of w
//        bit 31~0 - w[63:32] (Read/Write)
// 0x64 : reserved
// 0x68 : Data signal of x
//        bit 31~0 - x[31:0] (Read/Write)
// 0x6c : Data signal of x
//        bit 31~0 - x[63:32] (Read/Write)
// 0x70 : reserved
// 0x74 : Data signal of y
//        bit 31~0 - y[31:0] (Read/Write)
// 0x78 : Data signal of y
//        bit 31~0 - y[63:32] (Read/Write)
// 0x7c : reserved
// 0x80 : Data signal of z
//        bit 31~0 - z[31:0] (Read/Write)
// 0x84 : Data signal of z
//        bit 31~0 - z[63:32] (Read/Write)
// 0x88 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XKERNEL_GEMVER_CONTROL_ADDR_AP_CTRL    0x00
#define XKERNEL_GEMVER_CONTROL_ADDR_GIE        0x04
#define XKERNEL_GEMVER_CONTROL_ADDR_IER        0x08
#define XKERNEL_GEMVER_CONTROL_ADDR_ISR        0x0c
#define XKERNEL_GEMVER_CONTROL_ADDR_ALPHA_DATA 0x10
#define XKERNEL_GEMVER_CONTROL_BITS_ALPHA_DATA 32
#define XKERNEL_GEMVER_CONTROL_ADDR_BETA_DATA  0x18
#define XKERNEL_GEMVER_CONTROL_BITS_BETA_DATA  32
#define XKERNEL_GEMVER_CONTROL_ADDR_A_DATA     0x20
#define XKERNEL_GEMVER_CONTROL_BITS_A_DATA     64
#define XKERNEL_GEMVER_CONTROL_ADDR_U1_DATA    0x2c
#define XKERNEL_GEMVER_CONTROL_BITS_U1_DATA    64
#define XKERNEL_GEMVER_CONTROL_ADDR_V1_DATA    0x38
#define XKERNEL_GEMVER_CONTROL_BITS_V1_DATA    64
#define XKERNEL_GEMVER_CONTROL_ADDR_U2_DATA    0x44
#define XKERNEL_GEMVER_CONTROL_BITS_U2_DATA    64
#define XKERNEL_GEMVER_CONTROL_ADDR_V2_DATA    0x50
#define XKERNEL_GEMVER_CONTROL_BITS_V2_DATA    64
#define XKERNEL_GEMVER_CONTROL_ADDR_W_DATA     0x5c
#define XKERNEL_GEMVER_CONTROL_BITS_W_DATA     64
#define XKERNEL_GEMVER_CONTROL_ADDR_X_DATA     0x68
#define XKERNEL_GEMVER_CONTROL_BITS_X_DATA     64
#define XKERNEL_GEMVER_CONTROL_ADDR_Y_DATA     0x74
#define XKERNEL_GEMVER_CONTROL_BITS_Y_DATA     64
#define XKERNEL_GEMVER_CONTROL_ADDR_Z_DATA     0x80
#define XKERNEL_GEMVER_CONTROL_BITS_Z_DATA     64

