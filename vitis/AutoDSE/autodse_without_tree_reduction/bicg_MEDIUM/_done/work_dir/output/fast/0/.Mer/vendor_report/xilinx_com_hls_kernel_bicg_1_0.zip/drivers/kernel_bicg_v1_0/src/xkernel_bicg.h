// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XKERNEL_BICG_H
#define XKERNEL_BICG_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xkernel_bicg_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XKernel_bicg_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XKernel_bicg;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XKernel_bicg_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XKernel_bicg_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XKernel_bicg_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XKernel_bicg_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XKernel_bicg_Initialize(XKernel_bicg *InstancePtr, UINTPTR BaseAddress);
XKernel_bicg_Config* XKernel_bicg_LookupConfig(UINTPTR BaseAddress);
#else
int XKernel_bicg_Initialize(XKernel_bicg *InstancePtr, u16 DeviceId);
XKernel_bicg_Config* XKernel_bicg_LookupConfig(u16 DeviceId);
#endif
int XKernel_bicg_CfgInitialize(XKernel_bicg *InstancePtr, XKernel_bicg_Config *ConfigPtr);
#else
int XKernel_bicg_Initialize(XKernel_bicg *InstancePtr, const char* InstanceName);
int XKernel_bicg_Release(XKernel_bicg *InstancePtr);
#endif

void XKernel_bicg_Start(XKernel_bicg *InstancePtr);
u32 XKernel_bicg_IsDone(XKernel_bicg *InstancePtr);
u32 XKernel_bicg_IsIdle(XKernel_bicg *InstancePtr);
u32 XKernel_bicg_IsReady(XKernel_bicg *InstancePtr);
void XKernel_bicg_Continue(XKernel_bicg *InstancePtr);
void XKernel_bicg_EnableAutoRestart(XKernel_bicg *InstancePtr);
void XKernel_bicg_DisableAutoRestart(XKernel_bicg *InstancePtr);

void XKernel_bicg_Set_A(XKernel_bicg *InstancePtr, u64 Data);
u64 XKernel_bicg_Get_A(XKernel_bicg *InstancePtr);
void XKernel_bicg_Set_s(XKernel_bicg *InstancePtr, u64 Data);
u64 XKernel_bicg_Get_s(XKernel_bicg *InstancePtr);
void XKernel_bicg_Set_q(XKernel_bicg *InstancePtr, u64 Data);
u64 XKernel_bicg_Get_q(XKernel_bicg *InstancePtr);
void XKernel_bicg_Set_p(XKernel_bicg *InstancePtr, u64 Data);
u64 XKernel_bicg_Get_p(XKernel_bicg *InstancePtr);
void XKernel_bicg_Set_r(XKernel_bicg *InstancePtr, u64 Data);
u64 XKernel_bicg_Get_r(XKernel_bicg *InstancePtr);

void XKernel_bicg_InterruptGlobalEnable(XKernel_bicg *InstancePtr);
void XKernel_bicg_InterruptGlobalDisable(XKernel_bicg *InstancePtr);
void XKernel_bicg_InterruptEnable(XKernel_bicg *InstancePtr, u32 Mask);
void XKernel_bicg_InterruptDisable(XKernel_bicg *InstancePtr, u32 Mask);
void XKernel_bicg_InterruptClear(XKernel_bicg *InstancePtr, u32 Mask);
u32 XKernel_bicg_InterruptGetEnabled(XKernel_bicg *InstancePtr);
u32 XKernel_bicg_InterruptGetStatus(XKernel_bicg *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
