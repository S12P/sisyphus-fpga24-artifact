// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xkernel_bicg.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XKernel_bicg_CfgInitialize(XKernel_bicg *InstancePtr, XKernel_bicg_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XKernel_bicg_Start(XKernel_bicg *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_AP_CTRL) & 0x80;
    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XKernel_bicg_IsDone(XKernel_bicg *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XKernel_bicg_IsIdle(XKernel_bicg *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XKernel_bicg_IsReady(XKernel_bicg *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XKernel_bicg_Continue(XKernel_bicg *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_AP_CTRL) & 0x80;
    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_AP_CTRL, Data | 0x10);
}

void XKernel_bicg_EnableAutoRestart(XKernel_bicg *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XKernel_bicg_DisableAutoRestart(XKernel_bicg *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_AP_CTRL, 0);
}

void XKernel_bicg_Set_A(XKernel_bicg *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_A_DATA, (u32)(Data));
    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_A_DATA + 4, (u32)(Data >> 32));
}

u64 XKernel_bicg_Get_A(XKernel_bicg *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_A_DATA);
    Data += (u64)XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_A_DATA + 4) << 32;
    return Data;
}

void XKernel_bicg_Set_s(XKernel_bicg *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_S_DATA, (u32)(Data));
    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_S_DATA + 4, (u32)(Data >> 32));
}

u64 XKernel_bicg_Get_s(XKernel_bicg *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_S_DATA);
    Data += (u64)XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_S_DATA + 4) << 32;
    return Data;
}

void XKernel_bicg_Set_q(XKernel_bicg *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_Q_DATA, (u32)(Data));
    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_Q_DATA + 4, (u32)(Data >> 32));
}

u64 XKernel_bicg_Get_q(XKernel_bicg *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_Q_DATA);
    Data += (u64)XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_Q_DATA + 4) << 32;
    return Data;
}

void XKernel_bicg_Set_p(XKernel_bicg *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_P_DATA, (u32)(Data));
    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_P_DATA + 4, (u32)(Data >> 32));
}

u64 XKernel_bicg_Get_p(XKernel_bicg *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_P_DATA);
    Data += (u64)XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_P_DATA + 4) << 32;
    return Data;
}

void XKernel_bicg_Set_r(XKernel_bicg *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_R_DATA, (u32)(Data));
    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_R_DATA + 4, (u32)(Data >> 32));
}

u64 XKernel_bicg_Get_r(XKernel_bicg *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_R_DATA);
    Data += (u64)XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_R_DATA + 4) << 32;
    return Data;
}

void XKernel_bicg_InterruptGlobalEnable(XKernel_bicg *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_GIE, 1);
}

void XKernel_bicg_InterruptGlobalDisable(XKernel_bicg *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_GIE, 0);
}

void XKernel_bicg_InterruptEnable(XKernel_bicg *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_IER);
    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_IER, Register | Mask);
}

void XKernel_bicg_InterruptDisable(XKernel_bicg *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_IER);
    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_IER, Register & (~Mask));
}

void XKernel_bicg_InterruptClear(XKernel_bicg *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKernel_bicg_WriteReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_ISR, Mask);
}

u32 XKernel_bicg_InterruptGetEnabled(XKernel_bicg *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_IER);
}

u32 XKernel_bicg_InterruptGetStatus(XKernel_bicg *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XKernel_bicg_ReadReg(InstancePtr->Control_BaseAddress, XKERNEL_BICG_CONTROL_ADDR_ISR);
}

